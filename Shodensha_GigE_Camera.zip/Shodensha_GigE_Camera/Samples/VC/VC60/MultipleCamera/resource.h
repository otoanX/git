//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MultipleCamera.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_MULTIPLECAMERA_DIALOG       102
#define IDR_MAINFRAME                   128
#define IDC_DISPLAY1_STATIC             1000
#define IDC_ONLINE_NUM_EDIT             1001
#define IDC_DISPLAY3_STATIC             1002
#define IDC_DISPLAY2_STATIC             1003
#define IDC_DISPLAY4_STATIC             1004
#define IDC_USE_NUM_EDIT                1005
#define IDC_INIT_DEVICE_BUTTON          1006
#define IDC_EXPOUSE_EDIT                1007
#define IDC_GAIN_EDIT                   1008
#define IDC_SET_EXPOUSE_GAIN_BUTTON     1009
#define IDC_CONTINUS_MODE_RADIO         1010
#define IDC_TRIGGER_MODE_RADIO          1011
#define IDC_START_GRABBING_BUTTON       1012
#define IDC_STOP_GRABBING_BUTTON        1013
#define IDC_SOFTWARE_MODE_BUTTON        1014
#define IDC_SOFTWARE_ONCE_BUTTON        1015
#define IDC_HARDWARE_MODE_BUTTON        1016
#define IDC_SAVE_IMAGE_BUTTON           1017
#define IDC_CLEAR_COUNT_BUTTON          1018
#define IDC_CLOSE_BUTTON                1019
#define IDC_SELECT_CAMERA1_CHECK        1020
#define IDC_SELECT_CAMERA2_CHECK        1021
#define IDC_SELECT_CAMERA3_CHECK        1022
#define IDC_SELECT_CAMERA4_CHECK        1023
#define IDC_FRAME_COUNT1_EDIT           1024
#define IDC_FRAME_COUNT2_EDIT           1025
#define IDC_FRAME_COUNT3_EDIT           1026
#define IDC_FRAME_COUNT4_EDIT           1027
#define IDC_LOST_FRAME1_EDIT            1028
#define IDC_LOST_FRAME2_EDIT            1029
#define IDC_LOST_FRAME3_EDIT            1030
#define IDC_LOST_FRAME1_EDIT4           1031
#define IDC_LOST_FRAME4_EDIT            1031
#define IDC_CAMERA_INIT_STATIC          1032
#define IDC_ONLINE_NUM_STATIC           1033
#define IDC_USE_NUM_STATIC              1034
#define IDC_EXPOUSE_STATIC              1035
#define IDC_GAIN_STATIC                 1036
#define IDC_GRAB_CONTROL_STATIC         1037

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1038
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
