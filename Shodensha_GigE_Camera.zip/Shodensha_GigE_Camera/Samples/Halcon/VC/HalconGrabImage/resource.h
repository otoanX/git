//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by HalconGrabImage.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_HALCONGRABIMAGE_DIALOG      102
#define IDR_MAINFRAME                   128
#define IDC_DEVICE_COMBO                1001
#define IDC_ENUM_BUTTON                 1002
#define IDC_OPEN_BUTTON                 1003
#define IDC_CONTINUS_MODE_RADIO         1004
#define IDC_CLOSE_BUTTON                1005
#define IDC_TRIGGER_MODE_RADIO          1006
#define IDC_START_GRABBING_BUTTON       1007
#define IDC_STOP_GRABBING_BUTTON        1008
#define IDC_SOFTWARE_TRIGGER_CHECK      1009
#define IDC_SOFTWARE_ONCE_BUTTON        1010
#define IDC_EXPOSURE_EDIT               1011
#define IDC_GAIN_EDIT                   1012
#define IDC_FRAME_RATE_EDIT             1013
#define IDC_GET_PARAMETER_BUTTON        1014
#define IDC_BUTTON8                     1015
#define IDC_SET_PARAMETER_BUTTON        1015
#define IDC_DISPLAY_STATIC              1016
#define IDC_EXPOSURE_STATIC             1017
#define IDC_GAIN_STATIC                 1018
#define IDC_FRAME_RATE_STATIC           1019

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1020
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
